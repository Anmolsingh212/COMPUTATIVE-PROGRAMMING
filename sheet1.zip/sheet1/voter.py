age = int(input("Enter your age: "))

if age >= 18:
    print("Eligible to vote")
else:
    print("You are younger")
