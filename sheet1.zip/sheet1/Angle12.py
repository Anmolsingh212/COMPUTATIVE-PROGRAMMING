A = int(input("Enter first angle: "))
B = int(input("Enter second angle: "))
C = int(input("Enter third angle: "))
if A > 0 and B > 0 and C > 0 and (A + B + C == 180):
    print("Valid Triangle")
else:
    print("Not a Valid Triangle")
