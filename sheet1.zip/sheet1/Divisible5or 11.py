a=int(input("Enter the number:"))
if(a%5==0):
    print("number is divisible by 5")
elif(a%11==0):
    print("number is divisible by 11")
else:
    print("number is not divisible by 11 or 5")