n = int(input("Enter Number: "))

if n % 10 == 4 and n % 3 == 0:
    print("Yes, last digit is 4 and divisible by 3")
else:
    print("Not divisible by 4")
