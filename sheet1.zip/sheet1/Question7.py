a=int(input())
b=int(input())
c=int(input())
if (a+b+c==180):
    print("Triangle is valid")
else:
    print("Triangle is not valid")