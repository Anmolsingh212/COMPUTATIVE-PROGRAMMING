a=int(input("enter the year:"))
if(a%4==0 or a%400==0):
    print("this is leap year")
else:
    print("this is not leap year")