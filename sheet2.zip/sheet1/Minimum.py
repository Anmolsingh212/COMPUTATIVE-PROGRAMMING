a=int(input())
b=int(input())
c=int(input())
if(a<b and a<c):
    print("a is min")
elif (b<c and b<a):
    print("b is min")
else:
    print("c is min")