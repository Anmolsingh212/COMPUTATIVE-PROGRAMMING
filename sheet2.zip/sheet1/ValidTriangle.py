
n = int(input("Enter Number: "))

if n % 10 == 5 and n % 7 == 0:
    print("Yes, last digit is 5 and divisible by 7")
else:
    print("Not divisible by 7")
