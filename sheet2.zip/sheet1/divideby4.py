n = int(input("Enter the value: "))
if n % 10 == 4:
    print("Yes")
else:
    print("No")
