a=int(input("Enter the number:"))
b=int(input("Enter the number:"))
c=int(input("Enter the number:"))
if(a>b and a>c):
    print("a is maximum")
elif(b>c):
    print("b is maximum")
else:
    print("c is maximum")