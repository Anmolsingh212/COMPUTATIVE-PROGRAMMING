A = float(input("Enter first number: "))
B = float(input("Enter second number: "))
C = float(input("Enter third number: "))
D = float(input("Enter fourth number: "))
E = float(input("Enter fifth number: "))
average = (A + B + C + D + E) / 5
print("Average =", average)
