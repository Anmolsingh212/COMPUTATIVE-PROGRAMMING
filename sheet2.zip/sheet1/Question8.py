i=int(input("enter the numbers:"))
a=int(input())
b=int(input())
c=int(input())
d=int(input())
e=int(input())
total = a + b + c + d + e
avg = total / 5
print("Avg is:",avg)