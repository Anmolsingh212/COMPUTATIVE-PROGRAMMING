# * 
# * *
# * * *
# * * * *
# * * * * *
a=int(input("enter the no : "))
for i in range(1,a+1):
    for j in range(i):
        print("*",end=" ")
    print()