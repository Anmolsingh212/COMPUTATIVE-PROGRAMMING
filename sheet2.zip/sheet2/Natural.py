N = int(input("Enter the N: "))
for i in range(N, 0, -1):
    print(i, end=" ")
