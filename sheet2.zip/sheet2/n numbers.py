N = int(input("Enter N: "))
for i in range(1, N + 1):
    print(i)
