A = int(input("Enter A: "))
B = int(input("Enter B: "))
ans = 1
for i in range(B):
    ans = ans* A
print(ans,end=" ")
