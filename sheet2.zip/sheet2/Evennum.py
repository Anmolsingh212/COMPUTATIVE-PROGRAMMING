N = int(input("Enter N: "))
for i in range(2, N + 1, 2):
    print(i, end=" ")
