N = int(input("Enter the NUM: "))
for i in range(1, N + 1, 2):
    print(i)
