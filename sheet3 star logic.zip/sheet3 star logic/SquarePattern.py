# * * * * * 
# * * * * *
# * * * * *
# * * * * *
a=int(input("enter the  no : "))
for i in range(1,a):
    for j in range(a):
        print("*",end=" ")
    print()